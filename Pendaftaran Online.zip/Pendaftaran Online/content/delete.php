<div class="content">
    <div class="notification">
        <h3>Apakah anda yakin ingin menghapus anggota ini?</h3>
        <a href="index.php" class="btn">Batal</a> <a href="aksi/aksi_delete.php?id=<?php echo $_GET['id']; ?>" class="btn">Lanjutkan</a> 
    </div>
</div>